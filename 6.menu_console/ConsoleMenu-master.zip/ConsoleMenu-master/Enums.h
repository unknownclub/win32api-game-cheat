#pragma once
enum class Status { OFF, LOADING, ON };
enum class OptionTypes { Button, ProgressBar };