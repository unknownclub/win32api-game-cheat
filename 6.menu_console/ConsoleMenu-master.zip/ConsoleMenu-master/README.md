# ConsoleMenu

Add a Menu in a Console Application. Currently two types of elements are supported: "buttons" and progress bars.


## Getting Started

Download the Project. Add all files from the folder ConsoleMenu to your project. Add "#include "Menu.h"" at apropriate location.

## License

This project is licensed under the GNU General Public License - see the [LICENSE](LICENSE) file for details
